<!DOCTYPE html>
    <html>
<head></head>
<body>
<?php
include "publicheader.php";
?>
<h1>Symptoms of Dengue Fever</h1>
<div>
    <div style="float: right;margin-right: 100px">
        <img src="img/images.jpg"  height="150px" width="300px"></div>
    <div>
        <ol style="color:black">
            <li>Sudden, high fever.</li>
            <li>Severe headaches</li>
            <li>Pain behind the eyes.</li>
            <li>Severe joint and muscle pain</li>
            <li>Fatigue.</li>
            <li>Nausea</li>
            <li>Vomitting</li>
        </ol>
    </div>
<?php
include "footer.php";
?>
</body>
</html>